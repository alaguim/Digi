﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TesteDigi.Domain.Entities;

namespace TesteDigi.Service.Interface
{
    public interface IUserService : IBaseService<User>
    {
        Task<User> Authenticate(string email, string password);
    }
}
