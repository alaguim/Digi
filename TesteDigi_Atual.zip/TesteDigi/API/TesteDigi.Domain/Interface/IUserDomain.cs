﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TesteDigi.Domain.Entities;

namespace TesteDigi.Domain.Interface
{
    public interface IUserDomain : IBaseDomain<User>
    {
        Task<User> Authenticate(string email, string password);
    }
}
