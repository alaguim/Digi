﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TesteDigi.Infra.Migrations
{
    public partial class LoadDatabaseTeste : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            string insert = "INSERT INTO[dbo].[Users] ([Name],[Password],[Email],[Active],[CreationDate],[UpdateDate])";
            string values = "VALUES('ADMIN', '123', 'admin@teste.com', 1, CONVERT(varchar, GETDATE(), 120), null)";
            migrationBuilder.Sql(string.Concat(insert, values));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
