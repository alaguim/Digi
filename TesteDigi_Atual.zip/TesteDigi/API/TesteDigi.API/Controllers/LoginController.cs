﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using TesteDigi.Service.Interface;
using TesteDigi.Domain.Entities;
using System.Text;
using System.Threading.Tasks;

namespace TesteDigi.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IUserService _userService;

        public LoginController(IConfiguration configuration, IUserService userService)
        {
            _configuration = configuration;
            _userService = userService;
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> AuthenticateUser([FromBody] User user)
        {
            User _user = await _userService.Authenticate(user.Email, user.Password);

            if (_user != null)
            {
                var claims = new[]
                {
                     new Claim(ClaimTypes.Name, _user.Name),
                     new Claim(ClaimTypes.Email, _user.Email),
                };

                DateTime dateCreateToken = DateTime.Now;
                DateTime dateExpireToken = dateCreateToken + TimeSpan.FromMinutes(10);

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["SecurityKey"]));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                var tokenJwt = new JwtSecurityToken(issuer: _configuration["ValidKeyToken"],
                                                    audience: _configuration["ValidKeyToken"],
                                                    claims: claims,
                                                    expires: dateExpireToken,
                                                    notBefore: dateCreateToken,
                                                    signingCredentials: creds);

                return Ok(new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(tokenJwt)
                });
            }
            return BadRequest("Credenciais do usuário inválidas.");
        }
    }
}
