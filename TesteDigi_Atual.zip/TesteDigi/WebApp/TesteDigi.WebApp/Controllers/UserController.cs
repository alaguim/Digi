﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TesteDigi.WebApp.Models;
using TesteDigi.WebApp.Services;
using TesteDigi.WebApp.Util;

namespace TesteDigi.WebApp.Controllers
{
    public class UserController : Controller
    {
        private IUserService _userService;

        #region | Constructor  

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        #endregion

        #region | Index  

        public async Task<IActionResult> Index()
        {
            // Inicializa ViewModel de retorno
            var viewModel = new UserViewModel()
            {
                UserList = new List<UserModel>(),
                Filter = new UserFilter()
            };

            try
            {
                // Token logado
                var token = HttpContext.Session.GetString("Token");

                // Busca todos Usuários cadastrados
                List<UserModel> users = await _userService.GetUsersAsync(token);

                // Atualiza ViewModel de retorno
                viewModel.UserList = users;
            }
            catch (Exception ex)
            {
                TempData["ResponseError"] = string.Concat("Erro ao acessar serviço: ", ex.Message);
                return RedirectToAction("Index", "Home");
            }

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Index(UserViewModel viewModel)
        {
            var users = new List<UserModel>();

            // Inicializa ViewModel de retorno
            var viewModelReturn = new UserViewModel()
            {
                UserList = new List<UserModel>(),
                Filter = new UserFilter()
            };

            try
            {
                // Token logado
                var token = HttpContext.Session.GetString("Token");

                // Busca todos Usuários por filtro
                if (string.IsNullOrWhiteSpace(viewModel.Filter.Name))
                    users = await _userService.GetUsersAsync(token);
                else
                {
                    string actionName = KeyAppSettings.GetValueKey("ActionGetByName");
                    users = await _userService.GetUsersByPredicateAsync(actionName, viewModel.Filter.Name, token);
                }

                // Atualiza ViewModel de retorno
                viewModelReturn.UserList = users;
            }
            catch (Exception ex)
            {
                TempData["ResponseError"] = string.Concat("Erro ao acessar serviço: ", ex.Message);
                return RedirectToAction("Index", "Home");
            }

            return View(viewModelReturn);
        }

        #endregion

        #region ( Create ) 

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(UserModel userModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Token logado
                    var token = HttpContext.Session.GetString("Token");

                    // Busca Usuário
                    string actionName = KeyAppSettings.GetValueKey("ActionGetByEmail");
                    var users = await _userService.GetUsersByPredicateAsync(actionName, userModel.Email, token);

                    if (users.Count > 0)
                    {
                        ModelState.AddModelError("Email", "E-mail informado já existe. Informe outro.");
                        return View(userModel);
                    }
                    else
                    {
                        // Inicializa dados não digitados pelo usuário
                        userModel.Active = true;
                        userModel.CreationDate = DateTime.ParseExact(DateTime.Now.ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        userModel.UpdateDate = null;

                        await _userService.CreateUserAsync(userModel, token);
                    }
                }
                catch (Exception ex)
                {
                    TempData["ResponseError"] = string.Concat("Erro ao acessar serviço: ", ex.Message);
                    return RedirectToAction("Index", "Home");
                }

                return RedirectToAction("Index");
            }

            return View(userModel);
        }

        #endregion

        #region ( Edit ) 

        public async Task<IActionResult> Edit(int id)
        {
            UserModel viewModel = null;
            try
            {
                // Token logado
                var token = HttpContext.Session.GetString("Token");

                // Busca Usuário
                viewModel = await _userService.GetUserAsync(id, token);

                if (viewModel == null)
                    return new NotFoundResult();
            }
            catch (Exception ex)
            {
                TempData["ResponseError"] = string.Concat("Erro ao acessar serviço: ", ex.Message);
                return RedirectToAction("Index", "Home");
            }
            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, UserModel userModel)
        {
            if (id != userModel.UserId)
                return new BadRequestResult();

            if (ModelState.IsValid)
            {
                try
                {
                    var token = HttpContext.Session.GetString("Token");

                    // Busca Usuário
                    string actionName = KeyAppSettings.GetValueKey("ActionGetByEmail");
                    var users = await _userService.GetUsersByPredicateAsync(actionName, userModel.Email, token);

                    if (users.Count > 0 && users.ToList().FirstOrDefault().UserId != id)
                    {
                        ModelState.AddModelError("Email", "E-mail informado já existe. Informe outro.");
                        return View(userModel);
                    }
                    else
                    {
                        userModel.UpdateDate = DateTime.ParseExact(DateTime.Now.ToString(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                        await _userService.EditUserAsync(userModel, token);
                    }
                }
                catch (Exception ex)
                {
                    TempData["ResponseError"] = string.Concat("Erro ao acessar serviço: ", ex.Message);
                    return RedirectToAction("Index", "Home");
                }
                return RedirectToAction("Index");
            }

            return View(userModel);
        }

        #endregion

        #region ( Delete ) 

        public async Task<IActionResult> Delete(int id)
        {
            UserModel model = null;
            try
            {
                // Token logado
                var token = HttpContext.Session.GetString("Token");

                // Busca Usuário
                model = await _userService.GetUserAsync(id, token);

                if (model == null)
                    return new NotFoundResult();

                await _userService.RemoveUserAsync(id, token);
            }
            catch (Exception ex)
            {
                TempData["ResponseError"] = string.Concat("Erro ao acessar serviço: ", ex.Message);
                return RedirectToAction("Index", "Home");
            }

            return RedirectToAction("Index");
        }

        #endregion
    }
}