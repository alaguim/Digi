﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace TesteDigi.WebApp.Models
{
    public class TokenModel
    {
        public JwtSecurityToken TokenJwt { get; set; }
        public string Token { get; set; }
    }
}
