﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TesteDigi.WebApp.Models
{
    public class UserViewModel
    {
        public UserFilter Filter { get; set; }

        public IEnumerable<UserModel> UserList { get; set; }
    }

    public class UserFilter
    {
        [Display(Name = "Nome")]
        public string Name { get; set; }
    }
}
