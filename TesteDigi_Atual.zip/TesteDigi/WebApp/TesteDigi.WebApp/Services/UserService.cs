﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using TesteDigi.WebApp.Models;
using TesteDigi.WebApp.Util;

namespace TesteDigi.WebApp.Services
{
    public class UserService : IUserService
    {
        public async Task CreateUserAsync(UserModel user, string token)
        {
            HttpClient client = new HttpClient();
            string uriWebAPI = KeyAppSettings.GetValueKey("UriWebAPIUser");

            string content = JsonConvert.SerializeObject(user);
            var contentData = new StringContent(content, System.Text.Encoding.UTF8, "application/json");

            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.AcceptLanguage.Add(new StringWithQualityHeaderValue("nl-NL"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            using (var response = await client.PostAsync(uriWebAPI, contentData))
            {
                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        throw new System.Exception("Token inválido!");
                    else if (response.StatusCode != System.Net.HttpStatusCode.OK)
                        throw new System.Exception(response.ToString());
                }
            }
        }

        public async Task EditUserAsync(UserModel user, string token)
        {
            HttpClient client = new HttpClient();
            string uriWebAPI = KeyAppSettings.GetValueKey("UriWebAPIUser");

            string content = JsonConvert.SerializeObject(user);
            var contentData = new StringContent(content, System.Text.Encoding.UTF8, "application/json");

            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.AcceptLanguage.Add(new StringWithQualityHeaderValue("nl-NL"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            using (var response = await client.PutAsync(string.Concat(uriWebAPI, user.UserId.ToString()), contentData))
            {
                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        throw new System.Exception("Token inválido!");
                    else if (response.StatusCode != System.Net.HttpStatusCode.OK)
                        throw new System.Exception(response.ToString());
                }
            }
        }

        public async Task<string> GetTokenAsync(UserModel user)
        {
            HttpClient client = new HttpClient();

            string content = JsonConvert.SerializeObject(user);
            var contentData = new StringContent(content, System.Text.Encoding.UTF8, "application/json");
            string uriWebAPI = KeyAppSettings.GetValueKey("UriWebAPILogin");

            using (var response = await client.PostAsync(uriWebAPI, contentData))
            {
                if (response.IsSuccessStatusCode)
                {
                    var serSettings = new JsonSerializerSettings() { TypeNameHandling = TypeNameHandling.All };
                    string jsonString = await response.Content.ReadAsStringAsync();
                    TokenModel tokenModel = JsonConvert.DeserializeObject<TokenModel>(jsonString, serSettings);

                    return tokenModel.Token;
                }
                return string.Empty;
            }
        }

        public async Task<UserModel> GetUserAsync(int id, string token)
        {
            UserModel user = new UserModel();

            using (var client = new HttpClient())
            {
                string uriWebAPI = KeyAppSettings.GetValueKey("UriWebAPIUser");

                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.AcceptLanguage.Add(new StringWithQualityHeaderValue("nl-NL"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                using (var response = await client.GetAsync(string.Concat(uriWebAPI, id.ToString())))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var jsonString = await response.Content.ReadAsStringAsync();
                        user = JsonConvert.DeserializeObject<UserModel>(jsonString);
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        throw new System.Exception("Token inválido!");
                    else
                        throw new System.Exception(response.ToString());
                }
            }

            return user;
        }

        public async Task<List<UserModel>> GetUsersAsync(string token)
        {
            List<UserModel> users = new List<UserModel>();

            using (var client = new HttpClient())
            {
                string uriWebAPI = KeyAppSettings.GetValueKey("UriWebAPIUser");

                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.AcceptLanguage.Add(new StringWithQualityHeaderValue("nl-NL"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                using (var response = await client.GetAsync(uriWebAPI))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var jsonString = await response.Content.ReadAsStringAsync();
                        users = JsonConvert.DeserializeObject<List<UserModel>>(jsonString);
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        throw new System.Exception("Token inválido!");
                    else
                        throw new System.Exception(response.ToString());
                }
            }

            return users;
        }

        public async Task<List<UserModel>> GetUsersByPredicateAsync(string actionName, string value, string token)
        {
            List<UserModel> users = new List<UserModel>();

            using (var client = new HttpClient())
            {
                string uriWebAPI = KeyAppSettings.GetValueKey("UriWebAPIUser");

                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.AcceptLanguage.Add(new StringWithQualityHeaderValue("nl-NL"));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                using (var response = await client.GetAsync(string.Concat(uriWebAPI, actionName, value)))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var jsonString = await response.Content.ReadAsStringAsync();
                        users = JsonConvert.DeserializeObject<List<UserModel>>(jsonString);
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        throw new System.Exception("Token inválido!");
                    else
                        throw new System.Exception(response.ToString());
                }
            }

            return users;
        }

        public async Task RemoveUserAsync(int id, string token)
        {
            HttpClient client = new HttpClient();

            string uriWebAPI = KeyAppSettings.GetValueKey("UriWebAPIUser");

            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.AcceptLanguage.Add(new StringWithQualityHeaderValue("nl-NL"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            using (var response = await client.DeleteAsync(string.Concat(uriWebAPI, id.ToString())))
            {
                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        throw new System.Exception("Token inválido!");
                    else if (response.StatusCode != System.Net.HttpStatusCode.OK)
                        throw new System.Exception(response.ToString());
                }
            }
        }
    }
}
