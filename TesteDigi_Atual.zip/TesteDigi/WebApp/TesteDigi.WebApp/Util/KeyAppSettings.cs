﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace TesteDigi.WebApp.Util
{
    public static class KeyAppSettings
    {
        private static IConfigurationRoot configuration { get; set; }

        public static string GetValueKey(string key)
        {
            var builder = new ConfigurationBuilder()
                             .SetBasePath(Directory.GetCurrentDirectory())
                             .AddJsonFile("appsettings.json");

            configuration = builder.Build();

            return configuration.GetValue<string>(key);
        }
    }
}
