﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TesteDigi.WebApp.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage ="E-mail é obrigatório!")]
        [EmailAddress]
        [Display(Name = "E-mail")]
        public string EmailAddress { get; set; }

        [Required(ErrorMessage = "Senha é obrigatória!")]
        [DataType(DataType.Password)]
        [Display(Name = "Senha")]
        public string Password { get; set; }
    }
}
