﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TesteDigi.WebApp.Models
{
    public class UserModel
    {
        [Key]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Nome é obrigatório!")]
        [Display(Name = "Nome")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Senha é obrigatória!")]
        [Display(Name = "Senha")]
        public string Password { get; set; }

        [Required(ErrorMessage = "E-mail é obrigatório!")]
        [Display(Name = "E-mail")]
        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "Usuário Ativo")]
        public bool Active { get; set; }
       
        [Display(Name = "Data de Cadastro")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm:ss}")]
        [DataType(DataType.DateTime)]
        public DateTime CreationDate { get; set; }

        [Display(Name = "Data de Atualização")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm:ss}")]
        [DataType(DataType.DateTime)]
        public DateTime? UpdateDate { get; set; }
    }
}
