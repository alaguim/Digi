﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TesteDigi.WebApp.Models;

namespace TesteDigi.WebApp.Services
{
    public interface IUserService
    {
        Task CreateUserAsync(UserModel user, string token);
        Task EditUserAsync(UserModel user, string token);
        Task<UserModel> GetUserAsync(int id, string token);
        Task<List<UserModel>> GetUsersAsync(string token);
        Task<List<UserModel>> GetUsersByPredicateAsync(string actionName, string value, string token);
        Task<string> GetTokenAsync(UserModel user);
        Task RemoveUserAsync(int id, string token);
    }
}
