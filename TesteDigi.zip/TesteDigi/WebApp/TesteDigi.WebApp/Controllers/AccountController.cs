﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TesteDigi.WebApp.Models;
using TesteDigi.WebApp.Services;

namespace TesteDigi.WebApp.Controllers
{
    public class AccountController : Controller
    {
        private IUserService _userService;

        public AccountController(IUserService userService)
        {
            _userService = userService;
        }

        public IActionResult Index()
        {
            HttpContext.Session.Clear();
            return View();
        }

        [Route("Login")]
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                // Credenciais do Usuário logado
                var loginUser = new UserModel()
                {
                    Name = "Empty",
                    Email = viewModel.EmailAddress,
                    Password = viewModel.Password
                };

                // Busca um Token válido a partir do usuário informado
                var token = await _userService.GetTokenAsync(loginUser);

                if (token != string.Empty)
                {
                    HttpContext.Session.SetString("Token", token);
                    return RedirectToAction("Index", "Home");
                }
                else // Mensagem de Token inválido  
                    ModelState.AddModelError("InvalidToken", "E-mail/Senha informados são inválidos!");
            }

            return View("Index", viewModel);
        }

        [Route("logout")]
        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("username");
            return RedirectToAction("Index");
        }
    }
}