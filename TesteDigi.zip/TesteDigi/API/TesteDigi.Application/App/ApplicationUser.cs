﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using TesteDigi.Application.Interface;
using TesteDigi.Domain.Entities;
using TesteDigi.Domain.Interface;

namespace TesteDigi.Application.App
{
    public class ApplicationUser : IApplicationUser
    {
        #region | Objects  

        IDomainUser _domainUser;

        #endregion

        #region | Constructor  

        public ApplicationUser(IDomainUser domainUser)
        {
            _domainUser = domainUser;
        }

        #endregion

        #region | Public  

        public async Task Add(User entitie)
        {
            await _domainUser.Add(entitie);
        }

        public async Task<User> Authenticate(string email, string password)
        {
            return await _domainUser.Authenticate(email, password);
        }

        public async Task<IEnumerable<User>> GetAll()
        {
            return await _domainUser.GetAll();
        }

        public async Task<User> GetById(int id)
        {
            return await _domainUser.GetById(id);
        }

        public async Task<IEnumerable<User>> Find(Expression<Func<User, bool>> predicate)
        {
            return await _domainUser.Find(predicate); 
        }

        public async Task Remove(int id)
        {
            await _domainUser.Remove(id);
        }

        public async Task Update(User entitie)
        {
            await _domainUser.Update(entitie);
        }

        #endregion
    }
}
