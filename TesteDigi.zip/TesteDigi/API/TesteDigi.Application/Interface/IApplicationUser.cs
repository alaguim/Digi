﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TesteDigi.Domain.Entities;

namespace TesteDigi.Application.Interface
{
    public interface IApplicationUser : IApplicationBase<User>
    {
        Task<User> Authenticate(string email, string password);
    }
}
