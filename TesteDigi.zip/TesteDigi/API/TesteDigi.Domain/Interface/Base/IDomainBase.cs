﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace TesteDigi.Domain.Interface
{
    public interface IDomainBase<T> where T : class
    {
        Task Add(T entitie);

        Task<IEnumerable<T>> GetAll();

        Task<T> GetById(int id);

        Task<IEnumerable<T>> Find(Expression<Func<T, bool>> predicate);

        Task Remove(int id);

        Task Update(T entitie);
    }
}
