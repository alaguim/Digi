﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;
using TesteDigi.Domain.Entities;

namespace TesteDigi.Infra.Config
{
    public class AppDbContext : DbContext
    {
        public IConfigurationRoot Configuration { get; set; }

        public AppDbContext() { }

        public AppDbContext(DbContextOptions<AppDbContext> option) : base(option)
        {
            //Database.EnsureCreated();
        }

        public DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            if (!optionBuilder.IsConfigured)
                optionBuilder.UseSqlServer(ReturnConnectionString());
        }

        private string ReturnConnectionString()
        {
            var builder = new ConfigurationBuilder()
                             .SetBasePath(Directory.GetCurrentDirectory())
                             .AddJsonFile("appsettings.json", true, true);

            Configuration = builder.Build();
            string conexao = Configuration.GetConnectionString("DefaultConnection");

            return conexao;
        }
    }
}
