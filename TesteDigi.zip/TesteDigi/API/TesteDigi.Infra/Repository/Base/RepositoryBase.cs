﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using TesteDigi.Domain.Interface;
using TesteDigi.Infra.Config;

namespace TesteDigi.Infra.Repository
{
    public class RepositoryBase<T> : IDomainBase<T>, IDisposable where T : class
    {
        #region | Objects 

        protected DbContextOptionsBuilder<AppDbContext> _OptionsBuilder;

        #endregion

        #region | Constructor 

        public RepositoryBase()
        {
            _OptionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
        }

        #endregion

        #region | Public 

        public async Task Add(T Entitie)
        {
            using (var banco = new AppDbContext(_OptionsBuilder.Options))
            {
                banco.Add(Entitie);
                banco.SaveChanges();
            };
        }

        public async Task Remove(int Id)
        {
            using (var banco = new AppDbContext(_OptionsBuilder.Options))
            {
                var Objeto = banco.Set<T>().Find(Id);
                banco.Remove(Objeto);
                banco.SaveChanges();
            };
        }

        public async Task<IEnumerable<T>> GetAll()
        {
            using (var banco = new AppDbContext(_OptionsBuilder.Options))
            {
                return banco.Set<T>().ToList();
            };
        }

        public async Task Update(T Entitie)
        {
            using (var banco = new AppDbContext(_OptionsBuilder.Options))
            {
                banco.Update(Entitie);
                banco.SaveChanges();
            };
        }

        public async Task<T> GetById(int id)
        {
            using (var banco = new AppDbContext(_OptionsBuilder.Options))
            {
                return banco.Set<T>().Find(id);
            };           
        }

        public async Task<IEnumerable<T>> Find(Expression<Func<T, bool>> predicate)
        {
            using (var banco = new AppDbContext(_OptionsBuilder.Options))
            {
                return banco.Set<T>().Where(predicate).ToList();
            };
        }

        #endregion

        #region | Dispose  

        ~RepositoryBase()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool Status)
        {
            if (!Status) return;
        }

        #endregion
    }
}
