﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TesteDigi.Domain.Entities;
using TesteDigi.Domain.Interface;
using TesteDigi.Infra.Config;

namespace TesteDigi.Infra.Repository
{
    public class RepositoryUser : RepositoryBase<User>, IDomainUser
    {
        public async Task<User> Authenticate(string email, string password)
        {
            User user;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                return null;

            using (var banco = new AppDbContext(_OptionsBuilder.Options))
            {
                user = banco.Set<User>().ToList()
                      .SingleOrDefault(x =>
                                       x.Email == email &&
                                       x.Password == password &&
                                       x.Active == true);

                // Verifica se username existe
                if (user == null) { return null; }
            };

            // Sucesso Autenticação
            return user;
        }
    }
}
