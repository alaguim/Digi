﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TesteDigi.Application.Interface;
using TesteDigi.Domain.Entities;

namespace TesteDigi.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize()]
    public class UserController : ControllerBase
    {
        private readonly IApplicationUser _applicationUser;

        public UserController(IApplicationUser applicationUser)
        {
            _applicationUser = applicationUser;
        }

        public async Task<ActionResult<IEnumerable<User>>> Get()
        {
            return (List<User>)await _applicationUser.GetAll();           
        }

        [HttpGet("{id}", Name = "GetUser")]
        public async Task<IActionResult> Get([FromRoute] int id)
        {
            var user = await _applicationUser.GetById(id);

            if (user == null)
                return new NotFoundResult();

            return new ObjectResult(user);
        }

        [Route("[action]/{name}")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetByName([FromRoute]string name)
        {
            return (List<User>)await _applicationUser.Find(x => x.Name.Contains(name));
        }

        [Route("[action]/{email}")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetByEmail([FromRoute]string email)
        {
            return (List<User>)await _applicationUser.Find(x => x.Email.Equals(email));
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] User user)
        {
            if (user == null)
                return new BadRequestResult();

            await _applicationUser.Add(user);

            return new CreatedAtRouteResult("GetUser", new { id = user.UserId }, user);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] User user)
        {
            if (user == null || user.UserId != id)
                return new BadRequestResult();

            var _user = await _applicationUser.GetById(id);

            if (_user == null)
                return new NotFoundResult();
            else
            {
                _user.Name = user.Name;
                _user.Password = user.Password;
                _user.Email = user.Email;
                _user.Active = user.Active;
                _user.CreationDate = user.CreationDate;
                _user.UpdateDate = user.UpdateDate;
            }

            _applicationUser.Update(_user);

            return new NoContentResult();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var user = await _applicationUser.GetById(id);

            if (user == null)
                return new NotFoundResult();

            _applicationUser.Remove(id);

            return new NoContentResult();
        }
    }
}
